import styles from './rodape.module.css';

function Footer() {
    return (
        <footer className={styles.footer}>
            <div className={styles.footerContent}>
                <div className={styles.footerSection}>
                    <h4>Sobre Nós</h4>
                    <p>Somos uma loja dedicada a oferecer os melhores produtos com a melhor experiência de compra.</p>
                </div>
                <div className={styles.footerSection}>
                    <h4>Links Rápidos</h4>
                    <ul className={styles.footerLinks}>
                        <li><a href="/produtos">Produtos</a></li>
                        <li><a href="/sobre">Sobre</a></li>
                        <li><a href="/contato">Contato</a></li>
                    </ul>
                </div>
                <div className={styles.footerSection}>
                    <h4>Contato</h4>
                    <p>Email: contato@loja.com</p>
                    <p>Telefone: (11) 1234-5678</p>
                </div>
                <div className={styles.footerSection}>
                    <h4>Siga-nos</h4>
                    <div className={styles.socialLinks}>
                        <a href="#" className={styles.socialIcon}>Facebook</a>
                        <a href="#" className={styles.socialIcon}>Twitter</a>
                        <a href="#" className={styles.socialIcon}>Instagram</a>
                    </div>
                </div>
            </div>
            <div className={styles.footerBottom}>
                <p>&copy; {new Date().getFullYear()} Loja. Todos os direitos reservados.</p>
            </div>
        </footer>
    );
}

export default Footer;