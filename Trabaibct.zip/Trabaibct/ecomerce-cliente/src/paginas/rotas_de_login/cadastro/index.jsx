import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Cadastrar.css'; // Importando o arquivo CSS

const Cadastrar = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      alert('As senhas não coincidem!');
      return;
    }

    try {
      const response = await axios.post('http://localhost:5000/api/auth/register', {
        email,
        password,
      });

      if (response.status === 201) {
        alert('Cadastro realizado com sucesso!');
        navigate('/login'); // Redireciona para a página de login após o cadastro
      }
    } catch (error) {
      console.error('Erro ao fazer cadastro', error);
      alert('Erro ao fazer cadastro. Tente novamente.');
    }
  };

  return (
    <div className="register-container">
      <h1>Cadastrar</h1>
      <form onSubmit={handleRegister} className="register-form">
        <div className="form-group">
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="form-input"
          />
        </div>
        <div className="form-group">
          <label>Senha:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="form-input"
          />
        </div>
        <div className="form-group">
          <label>Confirmar Senha:</label>
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
            className="form-input"
          />
        </div>
        <button type="submit" className="register-button">Cadastrar</button>
      </form>
      <p className="toggle-auth">
        Já tem uma conta? <a href="/login">Entre aqui</a>
      </p>
    </div>
  );
};

export default Cadastrar;