import style from './home.module.css'


function Home() {
    return(
        <div>
            saqweq
        </div>
    )
}

export default Home