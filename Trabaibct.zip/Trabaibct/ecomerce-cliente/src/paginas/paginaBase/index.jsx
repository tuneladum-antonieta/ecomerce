import React, { useEffect } from 'react';
import Header from "../../componentes/header";
import Footer from "../../componentes/footer";
import Container from "../../componentes/container";
import { Outlet } from "react-router-dom";
import './PaginaBase.css';

function PaginaBase() {
    useEffect(() => {
        const snowContainer = document.querySelector('.snow');
        const numberOfFlakes = 50; // Número de flocos de neve

        for (let i = 0; i < numberOfFlakes; i++) {
            const flake = document.createElement('div');
            flake.className = 'snowflake';
            flake.style.left = Math.random() * 100 + 'vw';
            flake.style.animationDuration = Math.random() * 3 + 2 + 's';
            flake.style.opacity = Math.random();
            snowContainer.appendChild(flake);
        }
    }, []);

    return (
        <main className="pagina-base">
            <div className="snow"></div>
            <Header />
            <Container>
                <Outlet />
            </Container>
            <Footer />
        </main>
    );
}

export default PaginaBase;